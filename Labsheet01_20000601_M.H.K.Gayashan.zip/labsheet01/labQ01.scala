object labQ01{
    def main(args:Array[String])={
        var i:Int =2
        var j:Float=2
        var k:Int = 2
        var m:Float = 5
        var n:Int = 5
        var f:Float = 12.0F
        var g:Float = 4.0F
        var c:Char = 'X'
       

        println(k+12*m)
        println(m/j)
        println(n%j)
        println(m / j*j)
        println(f + 10*5 +g)
        println( (i+1)*n)


    }
}